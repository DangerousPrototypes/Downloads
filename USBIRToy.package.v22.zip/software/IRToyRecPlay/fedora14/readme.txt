Binary for fedora as compiled by MickM
http://dangerousprototypes.com/forum/viewtopic.php?f=29&t=2740&view=unread#p27131
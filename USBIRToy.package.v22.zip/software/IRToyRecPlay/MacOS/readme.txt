Mac OS Leopard 
Binary executable.  Might need library from IOS SDK from Apple.
http://dangerousprototypes.com/forum/viewtopic.php?f=29&t=2740&sid=9ba2fd06d04d2993f96ba9c90fc6acac
/* header  */



void EEPROMwrite (unsigned char addr, unsigned char data);
unsigned char EEPROMread(unsigned char addr);

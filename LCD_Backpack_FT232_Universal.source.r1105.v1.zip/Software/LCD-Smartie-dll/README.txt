Due to copyright reason,

The FTd2xx.dll and the corresponding ftd2xx.h header should be downloaded from the ftdi site:

http://www.ftdichip.com

This is still under early development and may not work

Use VS2010 free version

Note: Most of the codes was taken from McZ C# app.  This is an attemp to create a plugin for the smartie.



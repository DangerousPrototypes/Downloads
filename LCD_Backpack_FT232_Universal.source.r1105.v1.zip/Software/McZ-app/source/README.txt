Due to copyright reason,

The FTd2xx.dll and the corresponding ftd2xx.h header should be downloaded from the ftdi site:

http://www.ftdichip.com

This is still under early development 

Use VS2010 free version





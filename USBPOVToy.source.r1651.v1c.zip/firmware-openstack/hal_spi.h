#ifndef HAL_SPI_H
#define HAL_SPI_H

u8 hal_spi_rw(u8 c);
void hal_spi_init(void);

#endif

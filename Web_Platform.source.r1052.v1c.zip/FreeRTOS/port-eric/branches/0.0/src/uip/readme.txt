uIP is a very small implementation of the TCP/IP stack that is written
by Adam Dunkels <adam@sics.se>. More information can be obtained 
at the uIP homepage at http://www.sics.se/~adam/uip/.

This is version $Name: uip-1-0 $.

The directory structure look as follows:

apps/  - Example applications
doc/   - Documentation
lib/   - Library code used by some applications
uip/   - uIP TCP/IP stack code
unix/  - uIP as a user space process under FreeBSD or Linux

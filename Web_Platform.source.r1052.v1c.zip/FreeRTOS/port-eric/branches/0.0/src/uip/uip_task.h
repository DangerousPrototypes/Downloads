#ifndef _UIP_TASK_H
#define _UIP_TASK_H


void uip_appcall(void);
void uip_udp_appcall(void);
void vUipTask( void *pvParameters );

#endif

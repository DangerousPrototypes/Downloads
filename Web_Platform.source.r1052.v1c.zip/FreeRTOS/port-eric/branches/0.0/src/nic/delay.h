#ifndef _DELAY_H_
#define _DELAY_H_

#define  F_CPU  40000000  

void delay_ms(unsigned char ms);

#endif
 

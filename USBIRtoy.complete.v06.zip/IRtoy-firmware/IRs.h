/*
*
*	USB infrared remote control receiver transmitter firmware v1.0
*	License: creative commons - attribution, share-alike 
*	Copyright Ian Lesnet 2010
*	http://dangerousprototypes.com
*
*/
unsigned char irsservice(void);
void irssetup(void);
void irsInterruptHandlerHigh(void);


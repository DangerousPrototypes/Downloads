#define USB_VID 0x04D8
#define USB_PID 0XFD08

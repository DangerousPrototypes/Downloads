/* header */

// forward declarations
void initSPI(void);
void SPIworker(void);


// spi interrupt service routine
#define SPIisr	do { \
} while(0);
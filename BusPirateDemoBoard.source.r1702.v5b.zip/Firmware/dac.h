/* header */

void setDAC(unsigned char dac);
void enableDAC(void);
void disableDAC(void);
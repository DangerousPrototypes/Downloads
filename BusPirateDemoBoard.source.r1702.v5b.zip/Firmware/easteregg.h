/* header */

unsigned char isEE();
void doEE();
/* header */


unsigned int getADC(unsigned char adc);
void enableTS(void);
COnfiguration profile for use with OLS logic analyzer client v0.9.4+. Place in the /plugins/ directory.

http://www.lxtreme.nl/ols/
Windows binary built on windows7-64, using codeblocks 10.05.
http://dangerousprototypes.com/forum/viewtopic.php?f=29&t=2740&sid=9ba2fd06d04d2993f96ba9c90fc6acac
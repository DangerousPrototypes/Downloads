
void GetPulseTime (void);
void GetPulseFreq(void);
void irWInterruptHandlerHigh (void);
void irWidgetservice(void);

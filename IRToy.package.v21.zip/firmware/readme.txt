Enter update mode: Short the PGC and PGD pins and plug in the IR Toy.

For a simple firmware update run update-USBIRToy.vXX.bat

update-USBIRToy.vXX.bat - install latest IR Toy firmware

update-USBIRtoy-TVBGone.bat - install the TV B Gone firmware, plays TV POWER codes

USBIRToy.vXX-HaD.hex - firmware to program in the IR remote control receiver Ian posted at Hack a Day several years ago

USBIRToy-BLxFWyy-DUMP.hex - factory programming image with bootloader version x and firmware version yy, program with a PIC programmer.

bootloader.hex - bootloader to program into a new PIC chip, program with a PIC programmer. The factory programming image is a better option
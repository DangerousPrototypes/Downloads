void binIOperipheralset(unsigned char inByte);

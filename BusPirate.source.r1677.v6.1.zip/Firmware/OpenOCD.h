#ifndef OPENOCD_H_
#define OPENOCD_H_

void binOpenOCD(void);

#endif

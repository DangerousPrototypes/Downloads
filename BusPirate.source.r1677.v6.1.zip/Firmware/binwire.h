void binwire(void);


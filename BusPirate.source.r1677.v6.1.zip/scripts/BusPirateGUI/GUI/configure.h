#ifndef __CONF_H
#define __CONF_H

#define ENABLE_SPI      0
#define ENABLE_I2C      1
#define ENABLE_1WIRE    1
#define ENABLE_RAWWIRE  0
#define ENABLE_ASCII    1
#define ENABLE_JTAG     0

#endif


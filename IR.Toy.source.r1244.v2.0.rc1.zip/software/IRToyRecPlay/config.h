#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

#ifdef _WIN32
#define IS_WIN32 1
#else
#undef IS_WIN32
#endif


#endif // CONFIG_H_INCLUDED

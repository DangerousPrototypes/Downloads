/*
*
*	USB infrared remote control receiver transmitter firmware
*	License: creative commons - attribution, share-alike 
*	Copyright Ian Lesnet 2010
*	http://dangerousprototypes.com
*
*/
void usbbufservice(void);
unsigned char usbbufgetbyte(unsigned char *c);
void usbbufflush(void);

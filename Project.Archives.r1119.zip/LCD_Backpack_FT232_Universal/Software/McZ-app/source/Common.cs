﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace USB_LCD_Backpack
{
    class Common
    {
        const byte cursor_shift_left = 0x10; // Move cursor left
    }
}
